<?php 
session_start();
require 'functions.php';

// if (!isset($_SESSION['user'])) {
//     header("Location: login.php");
//     exit;
// }

 ?>

<!DOCTYPE html>
<html lang="id" class="no-js">
<head>
	<?php include 'link.php'; ?>
</head>

<body>

	<!-- Start Header Area -->
	<?php include 'header.php'; ?>
	<!-- End Header Area -->

	<!-- start banner Area -->
	<section class="banner-area">
		<div class="container">
			<div class="row fullscreen align-items-center justify-content-start">
				<div class="col-lg-12">
					<div class="">
						<!-- single-slide -->
						<div class="row single-slide align-items-center d-flex mt-5">
							<div class="col-lg-6 col-md-6">
								<div class="banner-content">
									<h2>Selamat Datang di Official Website UKOPI Universitas Lambung Mangkurat</h2>
              							<p class="mt-3 mb-4">Mari menghemat waktu antrian dengan memesan secara online.</p>

									<button onclick="window.location.href='menu/'" style="background-color:#6F01A2;" class="btn  text-white">Jelajahi Produk <i class="fas fa-long-arrow-alt-right px-1"></i></button>
								</div>
							</div>
							<div class="col-lg-5">
								
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End banner Area -->


	<!-- end features Area -->

	<!-- Start Lokasi -->
	<!-- <section class="category-area">
		<div class="container">
			<div class="section-title text-center">
				<h1>Lokasi Kami</h1>
			</div>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d418.68753152007207!2d114.59768017927861!3d-3.2882385857366536!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2de4236bdd451561%3A0xbd202d032d155744!2sKembar%20Laundry!5e0!3m2!1sid!2sid!4v1659440036415!5m2!1sid!2sid" style="width:100%;height: 400px; border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
	</section>
	<br><br><br> -->
	<!-- End Lokasi Area -->
	

	<!-- start footer Area -->
	<?php include 'footer.php'; ?>
	<!-- End footer Area -->

	<?php include 'plugin.php'; ?>
</body>

</html>